package com.udacity.gamedev.gigagal;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Level {

    // TODO: Add a GigaGal member variable


    public Level() {
        // TODO: Initialize GigaGal

    }

    public void update(float delta) {
        // TODO: Update GigaGal

    }

    public void render(SpriteBatch batch) {
        // TODO: Render GigaGal

    }

}
