package com.udacity.gamedev.gigagal.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GigaGal {

    public final static String TAG = GigaGal.class.getName();

    // TODO: Add a position


    public GigaGal() {
        // TODO: Initialize GigaGal's position with height = GIGAGAL_EYE_HEIGHT

    }

    public void update(float delta) {

    }

    public void render(SpriteBatch batch) {

        // TODO: Draw GigaGal's standing-right sprite at position - GIGAGAL_EYE_POSITION

    }
}
