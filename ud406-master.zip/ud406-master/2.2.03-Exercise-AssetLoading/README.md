# Asset Loading

This is going to a tricky one! In this exercise we'll set up the asset loading scheme for GigaGal and draw GigaGal for the first time.

We recommend following the TODOs in the following order:

1. build.gradle
2. Constants.java
3. Assets.java
4. GameplayScreen.java
