package com.udacity.gamedev.gigagal.entities;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class GigaGal {

    public final static String TAG = GigaGal.class.getName();

    public GigaGal() {

    }

    public void update(float delta) {

    }

    public void render(SpriteBatch batch) {

    }
}
