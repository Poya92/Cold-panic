package com.udacity.gamedev.gigagal;

import com.badlogic.gdx.ScreenAdapter;


public class GameplayScreen extends ScreenAdapter {

    public static final String TAG = GameplayScreen.class.getName();

    // TODO: Add a SpriteBatch


    // TODO: Add an ExtendViewport


    @Override
    public void show() {

        // TODO: Initialize the Assets instance


        // TODO: Initalize the SpriteBatch


        // TODO: Initialize the viewport

    }

    @Override
    public void resize(int width, int height) {
        // TODO: Update the viewport

    }

    @Override
    public void dispose() {
        // TODO: Dispose of the Assets instance


        // TODO: Dispose of the SpriteBatch

    }

    @Override
    public void render(float delta) {

        // TODO: Apply the viewport


        // TODO: Clear the screen to the BACKGROUND_COLOR


        // TODO: Set the SpriteBatch's projection matrix


        // TODO: Begin the SpriteBatch


        // TODO: Draw the standing right AtlasRegion


        // TODO: End the SpriteBatch

    }
}
