package com.udacity.gamedev.gigagal;

import com.badlogic.gdx.ScreenAdapter;

// TODO: Create GameplayScreen
public class GameplayScreen extends ScreenAdapter {

    public static final String TAG = GameplayScreen.class.getName();


    @Override
    public void show() {

    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void dispose() {

    }

    @Override
    public void render(float delta) {

    }
}
