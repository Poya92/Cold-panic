package com.udacity.gamedev.gigagal;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;


// TODO: Create Level
public class Level {

    public Level() {

    }

    public void update(float delta) {

    }

    public void render(SpriteBatch batch) {

    }

}
