package com.udacity.gamedev.gigagal.util;

// TODO: Create Constants
public class Constants {

}
