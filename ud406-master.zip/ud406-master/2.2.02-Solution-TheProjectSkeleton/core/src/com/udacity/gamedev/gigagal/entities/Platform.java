package com.udacity.gamedev.gigagal.entities;


// TODO: Create Platform
public class Platform {

}
