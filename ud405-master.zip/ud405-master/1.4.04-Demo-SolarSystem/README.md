# Working with an OrthographicCamera

Now that we've seen what an OrthographicCamera can do for us, let's see how to create, manipulate, and apply one!

Check out the TODOs to get started.
