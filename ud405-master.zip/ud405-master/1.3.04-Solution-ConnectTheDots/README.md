# Connect the Dots

Check out the TODOs to get started!

Also check out the Generator directory to see how we made the elephant.
